/*isto e para ao clicar no link, aparecer o formulario de registro*/
/*
let form = document.getElementById('form');
form.addEventListener('click',function(event){
    event.preventDefault();
form.style.display = 'block';
});*//*
var btnamarelo = document.getElementById('amarelo');
var form = document.getElementById('pontuacao');
form.addEventListener('submit', stop);
function stop(event){
    event.preventDefault();
}
btnamarelo.addEventListener('click');*/
